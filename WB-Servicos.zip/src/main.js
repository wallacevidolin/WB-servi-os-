const app = document.querySelector("#app");

const state = {
  mode: "cliente",
  requests: JSON.parse(localStorage.getItem("wb_requests") || "[]"),
  professionals: JSON.parse(localStorage.getItem("wb_professionals") || "[]"),
  credits: Number(localStorage.getItem("wb_credits") || "0")
};

const money = n => Number(n).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
const save = () => {
  localStorage.setItem("wb_requests", JSON.stringify(state.requests));
  localStorage.setItem("wb_professionals", JSON.stringify(state.professionals));
  localStorage.setItem("wb_credits", String(state.credits));
};

function header() {
  return `<header class="top"><div class="brand"><div class="logo">WB</div><div><strong>WB Serviços</strong><small>Seu serviço, mais perto.</small></div></div><button class="menu" id="menuBtn">☰</button></header>`;
}
function nav() {
  return `<nav class="tabs">
    <button data-page="inicio" class="tab active">Início</button>
    <button data-page="pedir" class="tab">Pedir serviço</button>
    <button data-page="profissional" class="tab">Sou profissional</button>
    <button data-page="creditos" class="tab">Créditos</button>
  </nav>`;
}
function footer() {
  return `<footer>WB Serviços · Grande São Paulo<br><small>Versão inicial demonstrativa. Cadastros ficam apenas neste navegador.</small></footer>`;
}
function render(page = "inicio") {
  document.querySelector("#app").innerHTML = header() + nav() + `<main id="content"></main>` + footer();
  document.querySelectorAll(".tab").forEach(b => {
    b.classList.toggle("active", b.dataset.page === page);
    b.addEventListener("click", () => render(b.dataset.page));
  });
  const content = document.querySelector("#content");
  if (page === "inicio") content.innerHTML = home();
  if (page === "pedir") content.innerHTML = requestForm();
  if (page === "profissional") content.innerHTML = professionalForm();
  if (page === "creditos") content.innerHTML = creditsPage();
  bind(page);
}
function home() {
  return `<section class="hero"><span class="pill">GRANDE SÃO PAULO</span><h1>Encontre o profissional certo para o seu serviço.</h1><p>Peça um orçamento ou cadastre-se para receber novas oportunidades.</p><div class="actions"><button class="primary" data-go="pedir">Solicitar serviço</button><button class="secondary" data-go="profissional">Quero trabalhar</button></div><div class="stats"><div><b>3</b><small>profissionais por pedido</small></div><div><b>Rápido</b><small>contato direto</small></div><div><b>WB</b><small>feito para conectar</small></div></div></section>
  <section class="section"><h2>Serviços populares</h2><div class="service-grid">
    ${["Pintura","Pedreiro e reforma","Drywall e forro","Elétrica","Encanamento","Limpeza"].map((s,i)=>`<button class="service" data-service="${s}"><span>${["🖌️","🧱","🏠","💡","🚿","🧹"][i]}</span><strong>${s}</strong><small>Solicitar orçamento →</small></button>`).join("")}
  </div></section>
  <section class="notice"><strong>Como funciona?</strong><p>O cliente descreve o serviço. A plataforma pode encaminhar a solicitação para até 3 profissionais. O sistema de pagamentos e a distribuição real de contatos precisam ser conectados antes do lançamento público.</p></section>`;
}
function requestForm() {
  return `<section class="section"><h1>Solicitar um serviço</h1><p class="muted">Conte o que você precisa. Os campos com * são obrigatórios.</p>
  <form id="requestForm" class="panel">
    <label>Seu nome *<input name="name" required maxlength="80" placeholder="Nome completo"></label>
    <label>WhatsApp *<input name="phone" required inputmode="tel" placeholder="(11) 99999-9999"></label>
    <label>Tipo de serviço *<select name="service" required><option value="">Selecione</option>${["Pintura","Pedreiro e reforma","Drywall e forro","Elétrica","Encanamento","Limpeza","Montagem","Outro"].map(x=>`<option>${x}</option>`).join("")}</select></label>
    <label>Região / cidade *<input name="area" required placeholder="Ex.: Santana, São Paulo"></label>
    <label>Descreva o serviço *<textarea name="description" required rows="4" maxlength="1200" placeholder="Explique o que precisa ser feito"></textarea></label>
    <button class="primary full" type="submit">Registrar solicitação</button>
    <p class="tiny">Demonstração local: seus dados não são enviados para um servidor.</p>
  </form><div id="requestResult"></div></section>`;
}
function professionalForm() {
  return `<section class="section"><h1>Cadastro profissional</h1><p class="muted">Apresente seus serviços para receber oportunidades.</p>
  <form id="professionalForm" class="panel">
    <label>Nome ou nome da empresa *<input name="name" required maxlength="100" placeholder="Seu nome profissional"></label>
    <label>WhatsApp *<input name="phone" required inputmode="tel" placeholder="(11) 99999-9999"></label>
    <label>Especialidade *<select name="service" required><option value="">Selecione</option>${["Pintura","Pedreiro e reforma","Drywall e forro","Elétrica","Encanamento","Limpeza","Montagem","Outro"].map(x=>`<option>${x}</option>`).join("")}</select></label>
    <label>Cidade / região atendida *<input name="area" required placeholder="Ex.: Zona Norte, São Paulo"></label>
    <label>Apresentação<textarea name="about" rows="3" maxlength="600" placeholder="Experiência, serviços e diferenciais"></textarea></label>
    <button class="primary full" type="submit">Salvar cadastro de teste</button>
    <p class="tiny">Este cadastro fica apenas neste navegador. Para uso real, será necessário banco de dados seguro.</p>
  </form><div id="professionalResult"></div>
  <section class="section"><h2>Profissionais cadastrados neste aparelho</h2>${state.professionals.length ? state.professionals.map(p=>`<article class="item"><strong>${escapeHtml(p.name)}</strong><p>${escapeHtml(p.service)} · ${escapeHtml(p.area)}</p></article>`).join("") : `<p class="muted">Ainda não há cadastros neste aparelho.</p>`}</section></section>`;
}
function creditsPage() {
  return `<section class="section"><h1>Créditos profissionais</h1><p class="muted">Modelo planejado: o profissional compra créditos para desbloquear contatos de clientes.</p>
  <div class="balance"><small>Saldo demonstrativo</small><strong>${state.credits} créditos</strong><small>Não representa dinheiro ou créditos reais.</small></div>
  <div class="packs">
    ${[{name:"1 crédito",price:5,credits:1},{name:"5 créditos",price:25,credits:5},{name:"12 créditos",price:50,credits:12}].map(p=>`<article class="pack"><h3>${p.name}</h3><strong>${money(p.price)}</strong><p>${p.credits} crédito(s)</p><button class="secondary buy-demo" data-credits="${p.credits}">Testar pacote</button></article>`).join("")}
  </div><div class="notice"><strong>Importante</strong><p>Os botões acima apenas simulam a compra. Não fazem cobrança. Pix/cartão exigem integração com um provedor de pagamentos, validação no servidor e configuração de credenciais.</p></div>
  <h2>Solicitações registradas neste aparelho</h2>${state.requests.length ? state.requests.map(r=>`<article class="item"><strong>${escapeHtml(r.service)}</strong><p>${escapeHtml(r.area)} · ${escapeHtml(r.name)}</p><small>${escapeHtml(r.description)}</small></article>`).join("") : `<p class="muted">Nenhuma solicitação de teste ainda.</p>`}</section>`;
}
function escapeHtml(s="") {
  return String(s).replace(/[&<>"']/g, c => ({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;" }[c]));
}
function bind(page) {
  document.querySelectorAll("[data-go]").forEach(b=>b.addEventListener("click",()=>render(b.dataset.go)));
  document.querySelectorAll("[data-service]").forEach(b=>b.addEventListener("click",()=>{
    render("pedir");
    const select = document.querySelector('[name="service"]');
    if (select) select.value = b.dataset.service;
  }));
  const rf = document.querySelector("#requestForm");
  if (rf) rf.addEventListener("submit", e=>{
    e.preventDefault();
    const d = Object.fromEntries(new FormData(rf));
    state.requests.unshift({...d, id: Date.now()});
    save();
    document.querySelector("#requestResult").innerHTML = `<div class="success">Solicitação de teste registrada neste aparelho. Nenhum profissional foi notificado.</div>`;
    rf.reset();
  });
  const pf = document.querySelector("#professionalForm");
  if (pf) pf.addEventListener("submit", e=>{
    e.preventDefault();
    const d = Object.fromEntries(new FormData(pf));
    state.professionals.unshift({...d, id: Date.now()});
    save();
    document.querySelector("#professionalResult").innerHTML = `<div class="success">Cadastro de teste salvo neste aparelho.</div>`;
    render("profissional");
  });
  document.querySelectorAll(".buy-demo").forEach(b=>b.addEventListener("click",()=>{
    state.credits += Number(b.dataset.credits); save(); render("creditos");
  }));
  document.querySelector("#menuBtn")?.addEventListener("click",()=>document.querySelector(".tabs")?.classList.toggle("show"));
}
render();
